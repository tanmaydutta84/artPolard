import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auction-active',
  templateUrl: './auction-active.component.html',
  styleUrls: ['./auction-active.component.scss']
})
export class AuctionActiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
