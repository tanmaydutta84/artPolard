import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sold-items',
  templateUrl: './sold-items.component.html',
  styleUrls: ['./sold-items.component.scss']
})
export class SoldItemsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
