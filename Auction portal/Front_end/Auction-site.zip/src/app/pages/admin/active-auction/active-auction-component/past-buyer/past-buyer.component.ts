import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-past-buyer',
  templateUrl: './past-buyer.component.html',
  styleUrls: ['./past-buyer.component.scss']
})
export class PastBuyerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
