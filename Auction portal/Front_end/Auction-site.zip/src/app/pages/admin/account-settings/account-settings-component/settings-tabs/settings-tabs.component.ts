import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings-tabs',
  templateUrl: './settings-tabs.component.html',
  styleUrls: ['./settings-tabs.component.scss']
})
export class SettingsTabsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
