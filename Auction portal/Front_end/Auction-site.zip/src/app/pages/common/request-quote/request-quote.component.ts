import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-quote',
  templateUrl: './request-quote.component.html',
  styleUrls: ['./request-quote.component.scss']
})
export class RequestQuoteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
