import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quote-by-phone',
  templateUrl: './quote-by-phone.component.html',
  styleUrls: ['./quote-by-phone.component.scss']
})
export class QuoteByPhoneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
