import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-active-auction',
  templateUrl: './active-auction.component.html',
  styleUrls: ['./active-auction.component.scss']
})
export class ActiveAuctionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
