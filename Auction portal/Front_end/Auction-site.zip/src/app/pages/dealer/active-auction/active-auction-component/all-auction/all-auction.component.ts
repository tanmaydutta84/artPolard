import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-auction',
  templateUrl: './all-auction.component.html',
  styleUrls: ['./all-auction.component.scss']
})
export class AllAuctionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
