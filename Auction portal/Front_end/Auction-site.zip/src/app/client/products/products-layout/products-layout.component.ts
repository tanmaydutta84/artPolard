import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-layout',
  templateUrl: './products-layout.component.html',
  styleUrls: ['./products-layout.component.scss']
})
export class ProductsLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
