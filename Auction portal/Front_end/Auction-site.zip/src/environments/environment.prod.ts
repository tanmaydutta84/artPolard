export const environment = {
  production: true,
  // baseAPIUrl: 'http://localhost:9091/api/',
  // ImagePath: "http://localhost:9091/uploads/"

  baseAPIUrl: 'http://159.89.170.52:9091/api/',
  ImagePath: 'http://159.89.170.52:9091/uploads/',
};
